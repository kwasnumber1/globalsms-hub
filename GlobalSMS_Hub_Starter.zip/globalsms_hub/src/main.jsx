import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { Globe2, MessageSquareText, ShieldCheck, CreditCard, Clock3, Search, ChevronDown, Menu, X, RefreshCw, Zap, CircleHelp, LockKeyhole, ArrowUpRight, CheckCircle2, Smartphone, WalletCards } from "lucide-react";
import "./style.css";

const countries = [
  { name: "Philippines", code: "+63", flag: "🇵🇭", available: 12 },
  { name: "United States", code: "+1", flag: "🇺🇸", available: 24 },
  { name: "United Kingdom", code: "+44", flag: "🇬🇧", available: 9 },
  { name: "Canada", code: "+1", flag: "🇨🇦", available: 7 },
  { name: "Australia", code: "+61", flag: "🇦🇺", available: 5 },
];
const plans = [
  { name: "Free Trial", price: "Rs. 0", detail: "Try the demo interface", items: ["Demo inbox preview", "One demo allocation", "No real SMS delivery"], featured: false },
  { name: "Starter", price: "Rs. 100", detail: "Entry-level package concept", items: ["Configurable credit allowance", "Temporary allocation concept", "Requires live provider"], featured: true },
  { name: "Plus", price: "Rs. 300", detail: "For more usage", items: ["Higher configurable allowance", "Usage history concept", "Requires live provider"], featured: false },
];
function App() {
  const [selected, setSelected] = useState(countries[0]);
  const [tab, setTab] = useState("numbers");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");
  const [demoNumber, setDemoNumber] = useState(null);
  const [messages, setMessages] = useState([]);
  const [showPlans, setShowPlans] = useState(false);
  const filtered = countries.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
  const startDemo = (country) => {
    setSelected(country);
    setDemoNumber({ country, id: Date.now() });
    setMessages([]);
    setTab("inbox");
    setNotice("Demo allocation created. This is not a real phone number and cannot receive SMS.");
  };
  const refreshInbox = () => setNotice("No real messages: a live SMS provider is not connected yet.");
  const nav = (value) => { setTab(value); setMobileOpen(false); setNotice(""); };
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
      <div className="brand"><div className="brand-icon"><MessageSquareText size={21}/></div><div><strong>GlobalSMS<span> Hub</span></strong><small>TEMPORARY SMS PLATFORM</small></div><button className="close-mobile" onClick={() => setMobileOpen(false)}><X size={20}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <button className={`nav-item ${tab==="numbers"?"active":""}`} onClick={() => nav("numbers")}><Globe2 size={18}/> Browse numbers</button>
      <button className={`nav-item ${tab==="inbox"?"active":""}`} onClick={() => nav("inbox")}><MessageSquareText size={18}/> SMS inbox <span className="nav-pill">Demo</span></button>
      <button className={`nav-item ${tab==="plans"?"active":""}`} onClick={() => nav("plans")}><CreditCard size={18}/> Plans & pricing</button>
      <div className="sidebar-bottom"><div className="secure-card"><ShieldCheck size={20}/><strong>Built with safety in mind</strong><p>Live SMS and payments are disabled until providers are configured.</p></div><div className="profile"><div className="avatar">G</div><div><strong>Guest workspace</strong><small>Prototype mode</small></div><ChevronDown size={16}/></div></div>
    </aside>
    {mobileOpen && <div className="scrim" onClick={() => setMobileOpen(false)} />}
    <main className="main">
      <header className="topbar"><button className="menu-button" onClick={() => setMobileOpen(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{tab==="numbers"?"Browse numbers":tab==="inbox"?"SMS inbox":"Plans & pricing"}</b></div><div className="top-actions"><span className="mode"><i/> DEMO MODE</span><button className="help-button" onClick={() => setNotice("This prototype uses sample UI only. Connect an authorized SMS provider and approved payment gateway before launch.")}><CircleHelp size={17}/> Help</button></div></header>
      <div className="content">
        <section className="hero"><div className="hero-copy"><div className="eyebrow"><Zap size={14}/> TEMPORARY SMS WORKSPACE</div><h1>SMS verification,<br/><span>made simple.</span></h1><p>Explore a temporary-number platform interface. Real numbers and live message delivery can be enabled after a compatible provider is connected.</p><div className="hero-buttons"><button className="primary" onClick={() => { document.getElementById("countries")?.scrollIntoView({behavior:"smooth"}); }}>Explore countries <ArrowUpRight size={17}/></button><button className="secondary" onClick={() => nav("plans")}>View plans</button></div><div className="hero-note"><ShieldCheck size={15}/> Transparent demo · No fake live OTPs</div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="phone"><div className="phone-top"><span>SMS Inbox</span><span className="signal">● ● ●</span></div><div className="phone-country">🇵🇭 <div><b>Philippines</b><small>Example inbox</small></div><span className="live-dot"/></div><div className="message-card"><div className="msg-logo">SMS</div><div><b>Inbox is ready</b><small>Waiting for provider connection</small></div></div><div className="phone-status"><span/><span/><span/></div><div className="phone-bottom">DEMO PREVIEW</div></div><div className="float-badge"><CheckCircle2 size={17}/><div><b>Provider-ready</b><small>Integration layer planned</small></div></div></div></section>
        <div className="stats"><div className="stat"><div className="stat-icon purple"><Globe2/></div><div><small>COUNTRY OPTIONS</small><strong>05</strong><span>Sample country list</span></div></div><div className="stat"><div className="stat-icon green"><MessageSquareText/></div><div><small>LIVE SMS STATUS</small><strong>Not connected</strong><span>Provider setup required</span></div></div><div className="stat"><div className="stat-icon orange"><WalletCards/></div><div><small>PAYMENT STATUS</small><strong>Test mode</strong><span>Merchant setup required</span></div></div></div>
        {notice && <div className="notice"><CircleHelp size={18}/><span>{notice}</span><button onClick={() => setNotice("")}><X size={16}/></button></div>}
        {tab==="numbers" && <section id="countries" className="section"><div className="section-heading"><div><div className="eyebrow">CHOOSE YOUR REGION</div><h2>Browse countries</h2><p>Select a country to preview the temporary allocation flow.</p></div><div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search countries"/></div></div><div className="country-grid">{filtered.map(c=><article className={`country-card ${selected.name===c.name?"selected":""}`} key={c.name}><div className="country-top"><span className="flag">{c.flag}</span><span className="availability"><i/>{c.available} sample slots</span></div><h3>{c.name}</h3><p>Dial code <b>{c.code}</b></p><div className="country-bottom"><span className="demo-tag">SAMPLE INVENTORY</span><button onClick={()=>startDemo(c)}>Preview <ArrowUpRight size={15}/></button></div></article>)}</div><div className="integration-note"><div className="note-icon"><LockKeyhole size={19}/></div><div><strong>Real inventory is not connected yet</strong><p>Country cards show illustrative availability only. Connect a provider API to display genuine inventory and receive incoming messages.</p></div><span className="tag-muted">DEMO DATA</span></div></section>}
        {tab==="inbox" && <section className="section"><div className="section-heading"><div><div className="eyebrow">YOUR MESSAGES</div><h2>SMS inbox</h2><p>Preview the inbox interface. No real SMS can arrive in demo mode.</p></div><button className="secondary refresh" onClick={refreshInbox}><RefreshCw size={16}/> Refresh inbox</button></div><div className="inbox-layout"><div className="inbox-card"><div className="inbox-head"><div><strong>Active allocation</strong><small>Temporary session preview</small></div><span className="demo-tag">DEMO</span></div>{demoNumber?<div className="allocation"><span className="flag big">{demoNumber.country.flag}</span><div><strong>{demoNumber.country.name} {demoNumber.country.code}</strong><small>Sample allocation · Not a real number</small></div><span className="timer"><Clock3 size={14}/> Preview</span></div>:<div className="empty"><div className="empty-icon"><Smartphone size={26}/></div><strong>No active allocation</strong><p>Choose a country and press Preview to see the interface.</p><button className="primary" onClick={()=>nav("numbers")}>Browse countries</button></div>}<div className="messages-area"><div className="messages-title">Incoming messages <span>0</span></div>{messages.length===0?<div className="message-empty"><MessageSquareText size={24}/><strong>No messages yet</strong><span>Real SMS requires a connected provider.</span></div>:null}</div></div><div className="side-info"><div className="side-info-icon"><ShieldCheck size={20}/></div><h3>Private by design</h3><p>Message access should be limited to the user who owns the allocation.</p><hr/><div className="mini-row"><span>Provider</span><b>Not connected</b></div><div className="mini-row"><span>Mode</span><b className="orange-text">Demo</b></div><div className="mini-row"><span>Payment</span><b>Disabled</b></div></div></div></section>}
        {tab==="plans" && <section className="section"><div className="section-heading centered"><div><div className="eyebrow">SIMPLE PRICING</div><h2>Plans that fit your needs</h2><p>Pricing examples only. No payment is collected in this prototype.</p></div></div><div className="plan-grid">{plans.map(p=><article className={`plan-card ${p.featured?"featured":""}`} key={p.name}>{p.featured&&<div className="popular">STARTER</div>}<h3>{p.name}</h3><p>{p.detail}</p><div className="price">{p.price}<small>{p.price==="Rs. 0"?"":" / package"}</small></div><ul>{p.items.map(i=><li key={i}><CheckCircle2 size={16}/>{i}</li>)}</ul><button className={p.featured?"primary":"secondary"} onClick={()=>setNotice("Checkout is disabled until an approved payment gateway is configured. No payment has been made.")}>{p.price==="Rs. 0"?"Explore demo":"Select package"}</button></article>)}</div><div className="integration-note"><div className="note-icon"><WalletCards size={19}/></div><div><strong>Easypaisa, JazzCash and card payments</strong><p>These payment methods require merchant onboarding, supported checkout links or APIs, and verified server-side callbacks before automatic credit activation can work.</p></div></div></section>}
        <footer><div className="footer-brand"><div className="brand-icon small"><MessageSquareText size={16}/></div><b>GlobalSMS Hub</b></div><span>Prototype build · Live services require authorized provider setup</span><div className="footer-links"><button onClick={()=>setNotice("Publish a privacy policy before collecting personal data.")}>Privacy</button><button onClick={()=>setNotice("Publish terms and acceptable-use rules before launch.")}>Terms</button><button onClick={()=>setNotice("Contact/help page should be configured before launch.")}>Support</button></div></footer>
      </div>
    </main>
  </div>
}
createRoot(document.getElementById("root")).render(<App />);
